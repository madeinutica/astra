import React from 'react';
import { Ad } from '@/types';

interface AdCardProps {
  ad: Ad;
  onClick?: () => void;
}

const AdCard: React.FC<AdCardProps> = ({ ad, onClick }) => {
  // Calculate color based on score
  const getScoreColor = (score: number) => {
    if (score >= 85) return 'bg-green-100 text-green-800';
    if (score >= 70) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-lg text-gray-900 truncate">{ad.name}</h3>
        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${ad.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
          {ad.status}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="text-sm">
          <p className="text-gray-500">Platform</p>
          <p className="font-medium">{ad.platform}</p>
        </div>
        <div className="text-sm">
          <p className="text-gray-500">Spend</p>
          <p className="font-medium">${ad.spend.toLocaleString()}</p>
        </div>
        <div className="text-sm">
          <p className="text-gray-500">ROAS</p>
          <p className="font-medium">{ad.roas.toFixed(2)}x</p>
        </div>
        <div className="text-sm">
          <p className="text-gray-500">CTR</p>
          <p className="font-medium">{(ad.ctr * 100).toFixed(2)}%</p>
        </div>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="text-sm">
          <p className="text-gray-500">Created</p>
          <p className="font-medium">{new Date(ad.createdAt).toLocaleDateString()}</p>
        </div>
        <div className={`text-sm font-semibold px-3 py-1 rounded-full ${getScoreColor(ad.score)}`}>
          Score: {ad.score}
        </div>
      </div>
    </div>
  );
};

export default AdCard;

import React from 'react';
import { Ad } from '@/types';

interface RadarAnalysisProps {
  ad: Ad;
}

const RadarAnalysis: React.FC<RadarAnalysisProps> = ({ ad }) => {
  // Mock AI analysis if not provided
  const aiAnalysis = ad.aiAnalysis || `
    Based on the metrics provided, this ad scores ${ad.score}/100.
    
    STRENGTHS:
    - Strong ROAS of ${ad.roas.toFixed(2)}x, which is above industry average
    - Good hook rate of ${(ad.hookRate * 100).toFixed(1)}%, indicating effective opening
    
    AREAS FOR IMPROVEMENT:
    - CTR of ${(ad.ctr * 100).toFixed(2)}% could be improved with more compelling visuals
    - Retention rate of ${(ad.retention * 100).toFixed(1)}% suggests content may lose viewer interest
    
    RECOMMENDATIONS:
    1. Test a more direct call-to-action to improve conversion
    2. Consider adding social proof elements to build trust
    3. Experiment with different hook styles to improve initial engagement
  `;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Radar Analysis</h2>
        <div className="flex items-center">
          <span className="text-sm mr-2">Ad Score:</span>
          <span className={`text-lg font-bold px-3 py-1 rounded-full ${
            ad.score >= 85 ? 'bg-green-100 text-green-800' : 
            ad.score >= 70 ? 'bg-yellow-100 text-yellow-800' : 
            'bg-red-100 text-red-800'
          }`}>
            {ad.score}/100
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-blue-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-2">Performance Metrics</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>ROAS</span>
                <span className="font-medium">{ad.roas.toFixed(2)}x</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${Math.min(ad.roas / 5 * 100, 100)}%` }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>CTR</span>
                <span className="font-medium">{(ad.ctr * 100).toFixed(2)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: `${Math.min(ad.ctr * 1000, 100)}%` }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Hook Rate</span>
                <span className="font-medium">{(ad.hookRate * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-yellow-600 h-2 rounded-full" style={{ width: `${Math.min(ad.hookRate * 100, 100)}%` }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Retention</span>
                <span className="font-medium">{(ad.retention * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{ width: `${Math.min(ad.retention * 100, 100)}%` }}></div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-2">Ad Details</h3>
          <div className="space-y-2">
            <div>
              <p className="text-sm text-gray-500">Name</p>
              <p className="font-medium">{ad.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Platform</p>
              <p className="font-medium">{ad.platform}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Status</p>
              <p className="font-medium">{ad.status}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Spend</p>
              <p className="font-medium">${ad.spend.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-semibold text-gray-900 mb-2">AI Insights</h3>
        <div className="prose prose-sm max-w-none">
          <pre className="whitespace-pre-wrap text-sm text-gray-700 bg-white p-4 rounded border border-gray-200">
            {aiAnalysis}
          </pre>
        </div>
      </div>
      
      <div className="mt-6 flex justify-end">
        <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">
          Generate Improvement Ideas
        </button>
      </div>
    </div>
  );
};

export default RadarAnalysis;

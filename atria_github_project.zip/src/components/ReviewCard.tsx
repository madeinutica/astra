import React from 'react';
import { Review } from '@/types';

interface ReviewCardProps {
  review: Review;
  onClick?: () => void;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ review, onClick }) => {
  // Calculate color based on sentiment
  const getSentimentColor = (sentiment: string) => {
    if (sentiment === 'Positive') return 'bg-green-100 text-green-800';
    if (sentiment === 'Neutral') return 'bg-blue-100 text-blue-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-3">
        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getSentimentColor(review.sentiment)}`}>
          {review.sentiment}
        </span>
        <span className="text-sm text-gray-500">
          {review.source}
        </span>
      </div>
      
      <div className="mb-4">
        <p className="text-gray-700 line-clamp-4">{review.content}</p>
      </div>
      
      <div>
        <p className="text-sm text-gray-500 mb-1">Keywords</p>
        <div className="flex flex-wrap gap-1">
          {review.keywords.map((keyword, index) => (
            <span key={index} className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {keyword}
            </span>
          ))}
        </div>
      </div>
      
      <div className="mt-3 text-right">
        <p className="text-xs text-gray-500">
          {new Date(review.createdAt).toLocaleDateString()}
        </p>
      </div>
    </div>
  );
};

export default ReviewCard;

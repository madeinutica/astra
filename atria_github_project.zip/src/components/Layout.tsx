"use client";

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Navbar onMenuToggle={toggleSidebar} />
      <Sidebar isOpen={sidebarOpen} />
      
      <div className="flex overflow-hidden bg-gray-50 pt-16 w-full">
        <div className="bg-gray-50 h-full w-full overflow-y-auto lg:ml-64">
          <main className="h-full">
            <div className="pt-6 px-4">
              {children}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default Layout;

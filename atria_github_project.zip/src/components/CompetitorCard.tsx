import React from 'react';
import { Competitor } from '@/types';

interface CompetitorCardProps {
  competitor: Competitor;
  onClick?: () => void;
}

const CompetitorCard: React.FC<CompetitorCardProps> = ({ competitor, onClick }) => {
  return (
    <div 
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-lg text-gray-900 truncate">{competitor.name}</h3>
        <a 
          href={competitor.website} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 text-sm"
          onClick={(e) => e.stopPropagation()}
        >
          Visit Site
        </a>
      </div>
      
      <div className="mb-3">
        <p className="text-sm text-gray-500 mb-1">Top Hooks</p>
        <div className="flex flex-wrap gap-1">
          {competitor.topHooks.map((hook, index) => (
            <span key={index} className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {hook}
            </span>
          ))}
        </div>
      </div>
      
      <div className="mb-3">
        <p className="text-sm text-gray-500 mb-1">Top Themes</p>
        <div className="flex flex-wrap gap-1">
          {competitor.topThemes.map((theme, index) => (
            <span key={index} className="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {theme}
            </span>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-500 mb-1">Emotions</p>
          <div className="flex flex-wrap gap-1">
            {competitor.emotions.map((emotion, index) => (
              <span key={index} className="bg-pink-100 text-pink-800 text-xs font-medium px-2.5 py-0.5 rounded">
                {emotion}
              </span>
            ))}
          </div>
        </div>
        <div>
          <p className="text-sm text-gray-500 mb-1">Personas</p>
          <div className="flex flex-wrap gap-1">
            {competitor.personas.map((persona, index) => (
              <span key={index} className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                {persona}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompetitorCard;

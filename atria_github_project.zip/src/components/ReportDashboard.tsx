import React from 'react';
import { ReportData } from '@/types';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface ReportDashboardProps {
  reportData: ReportData;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const ReportDashboard: React.FC<ReportDashboardProps> = ({ reportData }) => {
  const { summary, performance, topCreatives, trends } = reportData;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-blue-50 rounded-lg p-4">
          <p className="text-sm text-gray-500">Total Ads</p>
          <p className="text-2xl font-bold">{summary.totalAds}</p>
          <div className="flex justify-between text-xs mt-2">
            <span className="text-green-600">{summary.activeAds} Active</span>
            <span className="text-gray-600">{summary.pausedAds} Paused</span>
          </div>
        </div>
        
        <div className="bg-green-50 rounded-lg p-4">
          <p className="text-sm text-gray-500">Total Spend</p>
          <p className="text-2xl font-bold">${summary.totalSpend.toLocaleString()}</p>
          <p className="text-xs text-gray-600 mt-2">Top Performer: {summary.topPerformer}</p>
        </div>
        
        <div className="bg-yellow-50 rounded-lg p-4">
          <p className="text-sm text-gray-500">Average ROAS</p>
          <p className="text-2xl font-bold">{summary.averageROAS.toFixed(2)}x</p>
          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
            <div className="bg-yellow-500 h-1.5 rounded-full" style={{ width: `${Math.min(summary.averageROAS / 5 * 100, 100)}%` }}></div>
          </div>
        </div>
        
        <div className="bg-purple-50 rounded-lg p-4">
          <p className="text-sm text-gray-500">Average CTR</p>
          <p className="text-2xl font-bold">{(summary.averageCTR * 100).toFixed(2)}%</p>
          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
            <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${Math.min(summary.averageCTR * 1000, 100)}%` }}></div>
          </div>
        </div>
      </div>
      
      {/* Performance Chart */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Performance Over Time</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={performance}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
              <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="spend" stroke="#8884d8" name="Spend ($)" />
              <Line yAxisId="right" type="monotone" dataKey="roas" stroke="#82ca9d" name="ROAS (x)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Top Creatives */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Top Performing Creatives</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={topCreatives}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="score" fill="#8884d8" name="Ad Score" />
              <Bar dataKey="roas" fill="#82ca9d" name="ROAS" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Trends */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">Hook Types</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={trends.hookTypes}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="percentage"
                  nameKey="name"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {trends.hookTypes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4">Themes</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={trends.themes}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="percentage"
                  nameKey="name"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {trends.themes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportDashboard;

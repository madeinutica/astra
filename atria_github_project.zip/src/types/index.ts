// Types for Atria application
export interface Ad {
  id: string;
  name: string;
  status: string;
  spend: number;
  roas: number;
  ctr: number;
  hookRate: number;
  retention: number;
  score: number;
  platform: string;
  createdAt: string;
  aiAnalysis?: string;
}

export interface Competitor {
  id: string;
  name: string;
  website: string;
  topHooks: string[];
  topThemes: string[];
  emotions: string[];
  personas: string[];
  createdAt: string;
}

export interface Review {
  id: string;
  content: string;
  source: string;
  sentiment: string;
  keywords: string[];
  createdAt: string;
}

export interface ReportSummary {
  totalAds: number;
  activeAds: number;
  pausedAds: number;
  totalSpend: number;
  averageROAS: number;
  averageCTR: number;
  topPerformer: string;
}

export interface PerformanceData {
  date: string;
  spend: number;
  roas: number;
  ctr: number;
}

export interface TopCreative {
  id: string;
  name: string;
  platform: string;
  spend: number;
  roas: number;
  ctr: number;
  score: number;
}

export interface TrendData {
  name: string;
  percentage: number;
}

export interface ReportData {
  summary: ReportSummary;
  performance: PerformanceData[];
  topCreatives: TopCreative[];
  trends: {
    hookTypes: TrendData[];
    themes: TrendData[];
  };
}

export interface AdConcept {
  headline: string;
  hook: string;
  benefit: string;
  emotionalTrigger: string;
  cta: string;
}

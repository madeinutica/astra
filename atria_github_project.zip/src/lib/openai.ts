import OpenAI from 'openai';

// Initialize OpenAI client with environment variable
export const openaiClient = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Helper functions for OpenAI API
export async function generateCompletion(prompt: string, options = {}) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key is required');
    }
    
    const completion = await openaiClient.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are an AI assistant specialized in digital advertising and marketing analysis." },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 1000,
      ...options
    });
    
    return completion.choices[0].message.content;
  } catch (error) {
    console.error('Error generating OpenAI completion:', error);
    throw error;
  }
}

// Radar algorithm functions
export async function scoreAd(adData: any) {
  const prompt = `
    Score this ad based on the following metrics:
    - Ad spend: ${adData.spend}
    - ROAS: ${adData.roas}
    - CTR: ${adData.ctr}
    - Hook rate: ${adData.hookRate}
    - Retention: ${adData.retention}
    
    Provide a score from 0-100 and explain why this score was given. Also provide 3 specific recommendations to improve this ad.
  `;
  
  return generateCompletion(prompt);
}

// Competitor analysis functions
export async function analyzeCompetitor(competitorData: any) {
  const prompt = `
    Analyze this competitor's ad strategy based on the following information:
    - Top hooks: ${competitorData.topHooks.join(', ')}
    - Top themes: ${competitorData.topThemes.join(', ')}
    - Emotions: ${competitorData.emotions.join(', ')}
    - Personas: ${competitorData.personas.join(', ')}
    
    Provide insights on their strategy, what makes their ads effective, and how we might adapt some of their approaches.
  `;
  
  return generateCompletion(prompt);
}

// Video script transcription
export async function transcribeVideo(videoUrl: string) {
  const prompt = `
    Analyze this video ad at ${videoUrl}.
    Create a detailed transcription of what might be in this video ad, including:
    - The hook (first 3 seconds)
    - Main message
    - Call to action
    - Any key visuals that might be shown
    
    Format this as a proper video script with timestamps.
  `;
  
  return generateCompletion(prompt);
}

// Review mining functions
export async function analyzeReviews(reviews: any[]) {
  const reviewTexts = reviews.map(r => r.content).join('\n\n');
  
  const prompt = `
    Analyze these customer reviews and provide insights:
    ${reviewTexts}
    
    Identify:
    1. Key audience segments/personas
    2. Main pain points mentioned
    3. Most valued benefits
    4. Emotional triggers
    5. Suggested ad angles based on these reviews
    6. 3 compelling testimonial quotes that would work well in ads
  `;
  
  return generateCompletion(prompt);
}

// Generate ad concepts
export async function generateAdConcepts(productInfo: string, targetAudience: string) {
  const prompt = `
    Create 5 compelling ad concepts for:
    Product/Service: ${productInfo}
    Target Audience: ${targetAudience}
    
    For each concept include:
    1. A catchy headline
    2. Main hook/angle
    3. Key benefit to highlight
    4. Emotional trigger to use
    5. Call to action
  `;
  
  return generateCompletion(prompt);
}

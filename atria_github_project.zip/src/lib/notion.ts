import { Client } from '@notionhq/client';

// Initialize Notion client with environment variable
export const notionClient = new Client({
  auth: process.env.NOTION_API_KEY,
});

// Database IDs from environment variables
export const DATABASES = {
  ADS: process.env.NOTION_ADS_DATABASE_ID,
  COMPETITORS: process.env.NOTION_COMPETITORS_DATABASE_ID,
  REVIEWS: process.env.NOTION_REVIEWS_DATABASE_ID,
};

// Helper functions for Notion API
export async function queryDatabase(databaseId: string, filter = {}) {
  try {
    if (!databaseId) {
      throw new Error('Database ID is required');
    }
    
    const response = await notionClient.databases.query({
      database_id: databaseId,
      filter,
    });
    return response.results;
  } catch (error) {
    console.error('Error querying Notion database:', error);
    throw error;
  }
}

export async function createPage(databaseId: string, properties: any) {
  try {
    if (!databaseId) {
      throw new Error('Database ID is required');
    }
    
    const response = await notionClient.pages.create({
      parent: {
        database_id: databaseId,
      },
      properties,
    });
    return response;
  } catch (error) {
    console.error('Error creating Notion page:', error);
    throw error;
  }
}

export async function updatePage(pageId: string, properties: any) {
  try {
    if (!pageId) {
      throw new Error('Page ID is required');
    }
    
    const response = await notionClient.pages.update({
      page_id: pageId,
      properties,
    });
    return response;
  } catch (error) {
    console.error('Error updating Notion page:', error);
    throw error;
  }
}

// Notion property formatters
export const formatTitle = (text: string) => ({ 
  title: [{ text: { content: text } }] 
});

export const formatSelect = (name: string) => ({ 
  select: { name } 
});

export const formatMultiSelect = (names: string[]) => ({ 
  multi_select: names.map(name => ({ name })) 
});

export const formatNumber = (number: number) => ({ 
  number 
});

export const formatDate = (date: string | Date) => ({ 
  date: { start: new Date(date).toISOString() } 
});

export const formatUrl = (url: string) => ({ 
  url 
});

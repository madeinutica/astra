import React from 'react';
import Layout from '@/components/Layout';
import AdCard from '@/components/AdCard';
import ReportDashboard from '@/components/ReportDashboard';
import { ReportData } from '@/types';

export default function Home() {
  // Mock data for dashboard
  const mockReportData: ReportData = {
    summary: {
      totalAds: 25,
      activeAds: 18,
      pausedAds: 7,
      totalSpend: 24500,
      averageROAS: 2.8,
      averageCTR: 0.031,
      topPerformer: 'Summer Sale Promotion',
    },
    performance: [
      { date: '2025-05-01', spend: 850, roas: 2.4, ctr: 0.029 },
      { date: '2025-05-02', spend: 920, roas: 2.6, ctr: 0.031 },
      { date: '2025-05-03', spend: 780, roas: 2.2, ctr: 0.027 },
      { date: '2025-05-04', spend: 1050, roas: 3.1, ctr: 0.035 },
      { date: '2025-05-05', spend: 1120, roas: 3.3, ctr: 0.038 },
      { date: '2025-05-06', spend: 950, roas: 2.8, ctr: 0.032 },
      { date: '2025-05-07', spend: 890, roas: 2.5, ctr: 0.030 },
    ],
    topCreatives: [
      {
        id: '1',
        name: 'Summer Sale Promotion',
        platform: 'Facebook',
        spend: 1200,
        roas: 3.2,
        ctr: 0.035,
        score: 92,
      },
      {
        id: '2',
        name: 'Product Demo Video',
        platform: 'Instagram',
        spend: 850,
        roas: 2.1,
        ctr: 0.028,
        score: 78,
      },
      {
        id: '3',
        name: 'Customer Testimonial',
        platform: 'TikTok',
        spend: 650,
        roas: 1.8,
        ctr: 0.022,
        score: 65,
      },
    ],
    trends: {
      hookTypes: [
        { name: 'Question', percentage: 35 },
        { name: 'Statistic', percentage: 25 },
        { name: 'Story', percentage: 20 },
        { name: 'Problem-Solution', percentage: 15 },
        { name: 'Other', percentage: 5 },
      ],
      themes: [
        { name: 'Value', percentage: 30 },
        { name: 'Urgency', percentage: 25 },
        { name: 'Social Proof', percentage: 20 },
        { name: 'Exclusivity', percentage: 15 },
        { name: 'Other', percentage: 10 },
      ],
    },
  };

  // Mock top performing ads
  const topAds = [
    {
      id: '1',
      name: 'Summer Sale Promotion',
      status: 'Active',
      spend: 1200,
      roas: 3.2,
      ctr: 0.035,
      hookRate: 0.82,
      retention: 0.71,
      score: 92,
      platform: 'Facebook',
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      name: 'Product Demo Video',
      status: 'Active',
      spend: 850,
      roas: 2.1,
      ctr: 0.028,
      hookRate: 0.65,
      retention: 0.58,
      score: 78,
      platform: 'Instagram',
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      name: 'Customer Testimonial',
      status: 'Paused',
      spend: 650,
      roas: 1.8,
      ctr: 0.022,
      hookRate: 0.59,
      retention: 0.52,
      score: 65,
      platform: 'TikTok',
      createdAt: new Date().toISOString(),
    },
  ];

  return (
    <Layout>
      <div className="mb-4 w-full grid grid-cols-1 xl:grid-cols-2 2xl:grid-cols-3 gap-4">
        <div className="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 col-span-1 xl:col-span-2 2xl:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Atria Dashboard</h3>
              <span className="text-base font-normal text-gray-500">Ship winning ads 10x faster</span>
            </div>
            <div className="flex-shrink-0">
              <a href="/reports" className="text-sm font-medium text-blue-600 hover:bg-gray-100 rounded-lg p-2">View all reports</a>
            </div>
          </div>
          <ReportDashboard reportData={mockReportData} />
        </div>
      </div>
      
      <div className="mt-8 mb-4">
        <div className="w-full grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-3 gap-4">
          <div className="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 col-span-1 xl:col-span-3 2xl:col-span-3">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Top Performing Ads</h3>
                <span className="text-base font-normal text-gray-500">Your highest scoring creatives</span>
              </div>
              <div className="flex-shrink-0">
                <a href="/radar" className="text-sm font-medium text-blue-600 hover:bg-gray-100 rounded-lg p-2">View all ads</a>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {topAds.map((ad) => (
                <AdCard key={ad.id} ad={ad} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

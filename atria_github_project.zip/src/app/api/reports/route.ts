import { NextResponse } from 'next/server';
import { queryDatabase, DATABASES } from '@/lib/notion';

// GET /api/reports - Get reporting data
export async function GET(request: Request) {
  try {
    // Check if Notion API key and database ID are configured
    if (!process.env.NOTION_API_KEY || !DATABASES.ADS) {
      return NextResponse.json({ 
        error: 'Notion API key or Ads database ID not configured',
        mockMode: true,
        report: getMockReportData() 
      }, { status: 200 });
    }
    
    // In a production environment, we would:
    // 1. Query the Notion database for ads
    // 2. Aggregate the data to generate reports
    // 3. Return the aggregated data
    
    // For now, we'll use mock data until the Notion integration is fully set up
    const mockReportData = getMockReportData();
    
    return NextResponse.json({ report: mockReportData });
  } catch (error) {
    console.error('Error generating report:', error);
    return NextResponse.json({ 
      error: 'Failed to generate report, using mock data',
      mockMode: true,
      report: getMockReportData() 
    }, { status: 200 });
  }
}

// Helper function to get mock report data
function getMockReportData() {
  return {
    summary: {
      totalAds: 25,
      activeAds: 18,
      pausedAds: 7,
      totalSpend: 24500,
      averageROAS: 2.8,
      averageCTR: 0.031,
      topPerformer: 'Summer Sale Promotion',
    },
    performance: [
      { date: '2025-05-01', spend: 850, roas: 2.4, ctr: 0.029 },
      { date: '2025-05-02', spend: 920, roas: 2.6, ctr: 0.031 },
      { date: '2025-05-03', spend: 780, roas: 2.2, ctr: 0.027 },
      { date: '2025-05-04', spend: 1050, roas: 3.1, ctr: 0.035 },
      { date: '2025-05-05', spend: 1120, roas: 3.3, ctr: 0.038 },
      { date: '2025-05-06', spend: 950, roas: 2.8, ctr: 0.032 },
      { date: '2025-05-07', spend: 890, roas: 2.5, ctr: 0.030 },
    ],
    topCreatives: [
      {
        id: '1',
        name: 'Summer Sale Promotion',
        platform: 'Facebook',
        spend: 1200,
        roas: 3.2,
        ctr: 0.035,
        score: 92,
      },
      {
        id: '2',
        name: 'Product Demo Video',
        platform: 'Instagram',
        spend: 850,
        roas: 2.1,
        ctr: 0.028,
        score: 78,
      },
      {
        id: '3',
        name: 'Customer Testimonial',
        platform: 'TikTok',
        spend: 650,
        roas: 1.8,
        ctr: 0.022,
        score: 65,
      },
    ],
    trends: {
      hookTypes: [
        { name: 'Question', percentage: 35 },
        { name: 'Statistic', percentage: 25 },
        { name: 'Story', percentage: 20 },
        { name: 'Problem-Solution', percentage: 15 },
        { name: 'Other', percentage: 5 },
      ],
      themes: [
        { name: 'Value', percentage: 30 },
        { name: 'Urgency', percentage: 25 },
        { name: 'Social Proof', percentage: 20 },
        { name: 'Exclusivity', percentage: 15 },
        { name: 'Other', percentage: 10 },
      ],
    },
  };
}

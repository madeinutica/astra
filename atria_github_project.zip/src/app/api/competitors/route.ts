import { NextResponse } from 'next/server';
import { queryDatabase, DATABASES, formatTitle, formatSelect, formatMultiSelect, formatDate } from '@/lib/notion';
import { analyzeCompetitor, transcribeVideo } from '@/lib/openai';

// GET /api/competitors - Get all competitors
export async function GET(request: Request) {
  try {
    // Check if Notion API key and database ID are configured
    if (!process.env.NOTION_API_KEY || !DATABASES.COMPETITORS) {
      return NextResponse.json({ 
        error: 'Notion API key or Competitors database ID not configured',
        mockMode: true,
        competitors: getMockCompetitors() 
      }, { status: 200 });
    }
    
    // Query the Notion database
    const results = await queryDatabase(DATABASES.COMPETITORS as string);
    
    // Parse the results
    const competitors = results.map((page: any) => {
      const properties = page.properties;
      return {
        id: page.id,
        name: properties.Name?.title?.[0]?.text?.content || 'Unnamed Competitor',
        website: properties.Website?.url || '',
        topHooks: properties.TopHooks?.multi_select?.map((item: any) => item.name) || [],
        topThemes: properties.TopThemes?.multi_select?.map((item: any) => item.name) || [],
        emotions: properties.Emotions?.multi_select?.map((item: any) => item.name) || [],
        personas: properties.Personas?.multi_select?.map((item: any) => item.name) || [],
        createdAt: properties.CreatedAt?.date?.start || new Date().toISOString(),
      };
    });
    
    return NextResponse.json({ competitors });
  } catch (error) {
    console.error('Error fetching competitors:', error);
    
    // Fallback to mock data if there's an error
    return NextResponse.json({ 
      error: 'Failed to fetch competitors from Notion, using mock data',
      mockMode: true,
      competitors: getMockCompetitors() 
    }, { status: 200 });
  }
}

// POST /api/competitors/analyze - Analyze a competitor
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ 
        error: 'OpenAI API key not configured',
        mockMode: true,
        analysis: "This is a mock analysis. To get real AI-powered analysis, please configure your OpenAI API key."
      }, { status: 200 });
    }
    
    // Analyze the competitor using OpenAI
    const analysis = await analyzeCompetitor(body);
    
    return NextResponse.json({ analysis });
  } catch (error) {
    console.error('Error analyzing competitor:', error);
    return NextResponse.json({ error: 'Failed to analyze competitor' }, { status: 500 });
  }
}

// POST /api/competitors/transcribe - Transcribe a competitor's video ad
export async function transcribe(request: Request) {
  try {
    const body = await request.json();
    const { videoUrl } = body;
    
    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ 
        error: 'OpenAI API key not configured',
        mockMode: true,
        transcription: "This is a mock transcription. To get real AI-powered transcription, please configure your OpenAI API key."
      }, { status: 200 });
    }
    
    // Transcribe the video using OpenAI
    const transcription = await transcribeVideo(videoUrl);
    
    return NextResponse.json({ transcription });
  } catch (error) {
    console.error('Error transcribing video:', error);
    return NextResponse.json({ error: 'Failed to transcribe video' }, { status: 500 });
  }
}

// Helper function to get mock competitors
function getMockCompetitors() {
  return [
    {
      id: '1',
      name: 'AdGenius Pro',
      website: 'https://adgeniuspro.com',
      topHooks: ['Limited Time Offer', 'Social Proof', 'Problem-Solution'],
      topThemes: ['Value', 'Urgency', 'Exclusivity'],
      emotions: ['Trust', 'FOMO', 'Relief'],
      personas: ['Marketing Manager', 'Small Business Owner'],
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      name: 'CreativeBoost',
      website: 'https://creativeboost.io',
      topHooks: ['Question Hook', 'Statistic', 'Story'],
      topThemes: ['Innovation', 'Simplicity', 'Results'],
      emotions: ['Curiosity', 'Ambition', 'Confidence'],
      personas: ['Creative Director', 'Digital Marketer'],
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      name: 'AdMetrics',
      website: 'https://admetrics.com',
      topHooks: ['Data-Driven', 'ROI Focus', 'Case Study'],
      topThemes: ['Analytics', 'Performance', 'Optimization'],
      emotions: ['Security', 'Achievement', 'Control'],
      personas: ['Performance Marketer', 'E-commerce Manager'],
      createdAt: new Date().toISOString(),
    },
  ];
}

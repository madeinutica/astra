import { NextResponse } from 'next/server';
import { generateAdConcepts } from '@/lib/openai';

// POST /api/generate - Generate ad concepts
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { productInfo, targetAudience } = body;
    
    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ 
        error: 'OpenAI API key not configured',
        mockMode: true,
        concepts: "This is a mock response. To get real AI-generated ad concepts, please configure your OpenAI API key."
      }, { status: 200 });
    }
    
    // Generate ad concepts using OpenAI
    const concepts = await generateAdConcepts(productInfo, targetAudience);
    
    return NextResponse.json({ concepts });
  } catch (error) {
    console.error('Error generating ad concepts:', error);
    return NextResponse.json({ error: 'Failed to generate ad concepts' }, { status: 500 });
  }
}

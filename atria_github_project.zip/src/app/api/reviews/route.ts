import { NextResponse } from 'next/server';
import { queryDatabase, DATABASES, formatTitle, formatSelect, formatMultiSelect, formatDate } from '@/lib/notion';
import { analyzeReviews } from '@/lib/openai';

// GET /api/reviews - Get all reviews
export async function GET(request: Request) {
  try {
    // Check if Notion API key and database ID are configured
    if (!process.env.NOTION_API_KEY || !DATABASES.REVIEWS) {
      return NextResponse.json({ 
        error: 'Notion API key or Reviews database ID not configured',
        mockMode: true,
        reviews: getMockReviews() 
      }, { status: 200 });
    }
    
    // Query the Notion database
    const results = await queryDatabase(DATABASES.REVIEWS as string);
    
    // Parse the results
    const reviews = results.map((page: any) => {
      const properties = page.properties;
      return {
        id: page.id,
        content: properties.Content?.title?.[0]?.text?.content || 'No content',
        source: properties.Source?.select?.name || 'Unknown',
        sentiment: properties.Sentiment?.select?.name || 'Neutral',
        keywords: properties.Keywords?.multi_select?.map((item: any) => item.name) || [],
        createdAt: properties.CreatedAt?.date?.start || new Date().toISOString(),
      };
    });
    
    return NextResponse.json({ reviews });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    
    // Fallback to mock data if there's an error
    return NextResponse.json({ 
      error: 'Failed to fetch reviews from Notion, using mock data',
      mockMode: true,
      reviews: getMockReviews() 
    }, { status: 200 });
  }
}

// POST /api/reviews/analyze - Analyze customer reviews
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { reviews } = body;
    
    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ 
        error: 'OpenAI API key not configured',
        mockMode: true,
        analysis: "This is a mock analysis. To get real AI-powered analysis, please configure your OpenAI API key."
      }, { status: 200 });
    }
    
    // Analyze the reviews using OpenAI
    const analysis = await analyzeReviews(reviews);
    
    return NextResponse.json({ analysis });
  } catch (error) {
    console.error('Error analyzing reviews:', error);
    return NextResponse.json({ error: 'Failed to analyze reviews' }, { status: 500 });
  }
}

// Helper function to get mock reviews
function getMockReviews() {
  return [
    {
      id: '1',
      content: "This tool has completely transformed our ad strategy. We're seeing a 40% increase in ROAS since implementing Atria's recommendations. The Radar feature is incredibly accurate at predicting which ads will perform well.",
      source: 'Trustpilot',
      sentiment: 'Positive',
      keywords: ['ROAS', 'Radar', 'recommendations', 'performance'],
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      content: "The competitor analysis tool saved us countless hours of research. Being able to see exactly what strategies are working for our competitors has given us a huge advantage. Our CAC has decreased by 25% in just two months.",
      source: 'G2',
      sentiment: 'Positive',
      keywords: ['competitor analysis', 'strategies', 'CAC', 'time-saving'],
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      content: "The review mining feature is brilliant. We uploaded our customer feedback and immediately got actionable insights that we turned into new ad concepts. Three of these are now our top-performing ads.",
      source: 'Capterra',
      sentiment: 'Positive',
      keywords: ['review mining', 'insights', 'ad concepts', 'performance'],
      createdAt: new Date().toISOString(),
    },
  ];
}

import { NextResponse } from 'next/server';
import { queryDatabase, createPage, updatePage, DATABASES, formatTitle, formatSelect, formatNumber, formatDate } from '@/lib/notion';
import { scoreAd } from '@/lib/openai';

// GET /api/ads - Get all ads
export async function GET(request: Request) {
  try {
    // Check if Notion API key and database ID are configured
    if (!process.env.NOTION_API_KEY || !DATABASES.ADS) {
      return NextResponse.json({ 
        error: 'Notion API key or Ads database ID not configured',
        mockMode: true,
        ads: getMockAds() 
      }, { status: 200 });
    }
    
    // Query the Notion database
    const results = await queryDatabase(DATABASES.ADS as string);
    
    // Parse the results
    const ads = results.map((page: any) => {
      const properties = page.properties;
      return {
        id: page.id,
        name: properties.Name?.title?.[0]?.text?.content || 'Untitled Ad',
        status: properties.Status?.select?.name || 'Unknown',
        spend: properties.Spend?.number || 0,
        roas: properties.ROAS?.number || 0,
        ctr: properties.CTR?.number || 0,
        hookRate: properties.HookRate?.number || 0,
        retention: properties.Retention?.number || 0,
        score: properties.Score?.number || 0,
        platform: properties.Platform?.select?.name || 'Unknown',
        createdAt: properties.CreatedAt?.date?.start || new Date().toISOString(),
      };
    });
    
    return NextResponse.json({ ads });
  } catch (error) {
    console.error('Error fetching ads:', error);
    
    // Fallback to mock data if there's an error
    return NextResponse.json({ 
      error: 'Failed to fetch ads from Notion, using mock data',
      mockMode: true,
      ads: getMockAds() 
    }, { status: 200 });
  }
}

// POST /api/ads - Create a new ad
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Score the ad using OpenAI
    let aiAnalysis;
    try {
      aiAnalysis = await scoreAd(body);
    } catch (error) {
      console.error('Error scoring ad with OpenAI:', error);
      aiAnalysis = 'AI analysis unavailable';
    }
    
    // Check if Notion API key and database ID are configured
    if (!process.env.NOTION_API_KEY || !DATABASES.ADS) {
      return NextResponse.json({ 
        error: 'Notion API key or Ads database ID not configured',
        mockMode: true,
        ad: {
          id: Date.now().toString(),
          ...body,
          score: Math.floor(Math.random() * 30) + 70, // Random score between 70-100
          aiAnalysis,
          createdAt: new Date().toISOString(),
        }
      }, { status: 200 });
    }
    
    // Create the page in Notion
    const properties = {
      Name: formatTitle(body.name),
      Status: formatSelect(body.status),
      Spend: formatNumber(body.spend),
      ROAS: formatNumber(body.roas),
      CTR: formatNumber(body.ctr),
      HookRate: formatNumber(body.hookRate),
      Retention: formatNumber(body.retention),
      Score: formatNumber(body.score || Math.floor(Math.random() * 30) + 70),
      Platform: formatSelect(body.platform),
      CreatedAt: formatDate(new Date()),
    };
    
    const createdPage = await createPage(DATABASES.ADS as string, properties);
    
    return NextResponse.json({ 
      ad: {
        id: createdPage.id,
        ...body,
        aiAnalysis,
        createdAt: new Date().toISOString(),
      }
    });
  } catch (error) {
    console.error('Error creating ad:', error);
    return NextResponse.json({ error: 'Failed to create ad' }, { status: 500 });
  }
}

// PUT /api/ads/:id - Update an existing ad
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;
    
    // Check if Notion API key is configured
    if (!process.env.NOTION_API_KEY) {
      return NextResponse.json({ 
        error: 'Notion API key not configured',
        mockMode: true,
        ad: {
          id,
          ...updates,
          updatedAt: new Date().toISOString(),
        }
      }, { status: 200 });
    }
    
    // Update the page in Notion
    const properties: any = {};
    
    if (updates.name) properties.Name = formatTitle(updates.name);
    if (updates.status) properties.Status = formatSelect(updates.status);
    if (updates.spend !== undefined) properties.Spend = formatNumber(updates.spend);
    if (updates.roas !== undefined) properties.ROAS = formatNumber(updates.roas);
    if (updates.ctr !== undefined) properties.CTR = formatNumber(updates.ctr);
    if (updates.hookRate !== undefined) properties.HookRate = formatNumber(updates.hookRate);
    if (updates.retention !== undefined) properties.Retention = formatNumber(updates.retention);
    if (updates.score !== undefined) properties.Score = formatNumber(updates.score);
    if (updates.platform) properties.Platform = formatSelect(updates.platform);
    
    const updatedPage = await updatePage(id, properties);
    
    return NextResponse.json({ 
      ad: {
        id,
        ...updates,
        updatedAt: new Date().toISOString(),
      }
    });
  } catch (error) {
    console.error('Error updating ad:', error);
    return NextResponse.json({ error: 'Failed to update ad' }, { status: 500 });
  }
}

// Helper function to get mock ads
function getMockAds() {
  return [
    {
      id: '1',
      name: 'Summer Sale Promotion',
      status: 'Active',
      spend: 1200,
      roas: 3.2,
      ctr: 0.035,
      hookRate: 0.82,
      retention: 0.71,
      score: 92,
      platform: 'Facebook',
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      name: 'Product Demo Video',
      status: 'Active',
      spend: 850,
      roas: 2.1,
      ctr: 0.028,
      hookRate: 0.65,
      retention: 0.58,
      score: 78,
      platform: 'Instagram',
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      name: 'Customer Testimonial',
      status: 'Paused',
      spend: 650,
      roas: 1.8,
      ctr: 0.022,
      hookRate: 0.59,
      retention: 0.52,
      score: 65,
      platform: 'TikTok',
      createdAt: new Date().toISOString(),
    },
  ];
}
